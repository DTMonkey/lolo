# -*- coding: utf-8 -*-
##############################################################################
#    
#    Copyright (C) 2015 Dusal.net
#
##############################################################################

{
    "name" : "Branding, barcode, available products of Point of Sale",
    'summary' : "POS Branding, POS company logo, POS barcode, Available products POS, Product quantity, Available quantity of products on POS, POS ticket, POS quantity, quantity",
    "version" : "2.5",
    "description": """
        This module change POS Odoo logo with your company logo and add barcode and logo on POS ticket. Also it included quantity of available products feature. Contact and support email: almas@dusal.net
    """,
    'author' : 'Dusal Solutions',
    'support': 'almas@dusal.net',
    'license': 'Other proprietary',
    'category' : 'Point of Sale',
    'price': 25, 
    'currency': 'EUR',
    'images': ['static/images/main_screenshot.png', 'static/images/screenshot1.png', 'static/images/screenshot.png', 'static/images/screenshot2.png', 'static/images/ss1.png', 'static/images/ss3.png', 'static/images/ss4.png', 'static/images/ss5.png', 'static/images/ss2.png', 'static/images/ss6.png', 'static/images/ss7.png'],
    "depends" : [
                 "point_of_sale",
    ],
    "data" : [  'views/views.xml',
                'views/templates.xml',
                ],
    'qweb': ['static/src/xml/pos.xml',],
    'js': [
        'static/src/js/pos.js',
    ],
    "auto_install": False,
    "installable": True,
}

How to use this module?
==============

Just install and it will work. 

If you have any questions then you can contact us via following email. Support email: almas@dusal.net

Changelog
========

version 2.1 - Fixed quantity float bug.

version 2.2 - Fixed company logo bug on Google Chrome.

version 2.3 - Fixed qty_available bug. Now it's possible to use with pos_cache.

version 2.4 - Fixed barcode on POS Reciept on latest versions.

version 2.5 - Current warehouse quantity fix on main Warehouse.

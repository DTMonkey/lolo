# -*- coding: utf-8 -*-
##############################################################################
#
#    Addon for Odoo sale by Dusal.net
#    Copyright (C) 2015 Dusal.net Almas
#
##############################################################################


import openerp
from openerp import SUPERUSER_ID
from openerp import tools
from openerp import fields, osv
from openerp import models

class pos_config(models.Model):
    _inherit = 'pos.config'

    print_company_logo = fields.Boolean('Print company logo', readonly=False, index=True, help="Print company logo on receipt", default=False)
    print_orderno_barcode = fields.Boolean('Print barcode', readonly=False, index=True, help="Print POS order number as barcode on receipt", default=False)

odoo.define('dusal_pos.dusal_pos', function (require) {
"use strict";
    
    
    var models = require('point_of_sale.models');
    var screens = require('point_of_sale.screens');
    var core = require('web.core');
    var utils = require('web.utils');
    var Model = require('web.DataModel');
    var round_pr = utils.round_precision;
    var QWeb     = core.qweb;
    

    //var module = instance.point_of_sale;
    //var QWeb     = instance.web.qweb;
    
    models.load_models({
        model: 'res.company',
        fields: ['logo'],
        loaded: function(self,companies){
            $.each(companies, function(){
                $.extend(self.company || {}, this)
            });
        },
    })
    
    
    screens.ReceiptScreenWidget.include({
        render_receipt: function() {
            var self = this;
            this._super();
            $("#ticket-barcode").barcode($("#ticket-barcode").text(), "code128", {'showHRI':false, barWidth:2, output: 'bmp'});
        },
        print: function() {
            this.pos.get('selectedOrder')._printed = true;
            console.log(this.pos);
            setTimeout(function () {
                window.print();
            }, 1500);
        },
    });
    
    var PosModelSuper = models.PosModel;

    models.PosModel = models.PosModel.extend({
        initialize: function (session, attributes) {
            var product_model = _.find(this.models, function(model){ return model.model === 'product.product'; });
            product_model.fields.push('qty_available');
            var res = PosModelSuper.prototype.initialize.call(this, session, attributes);
            return res;
        },
        load_server_data: function(){            
            var self = this;
            var ready = PosModelSuper.prototype.load_server_data.call(this).then(function(){
                //console.log(self.config);
                var products = new Model('product.product')
                .query(['qty_available'])
                .filter([['sale_ok','=',true],['available_in_pos','=',true]])
                .context({'location': self.config.stock_location_id[0]})
                .all();
                return products;
            }).then(function(products){
                $.each(products, function(){
                    //console.log(this);
                    $.extend(self.db.get_product_by_id(this.id) || {}, this);
                });
                return $.when();
            });
            return ready;
        },
        get_unit: function(product){
            var self = this;
            var unit_id = product.uom_id;
            if(!unit_id){
                return undefined;
            }
            var unit_id0 = unit_id[0];
            if(!self.units_by_id[unit_id0]){
                return undefined;
            }
            return self.units_by_id[unit_id0];
        },
        refresh_qty_available:function(product){
            var $elem = $("[data-product-id='"+product.id+"'] .qty-tag");
            var unit = this.get_unit(product);
            if(unit && unit.rounding){
                var qty_available_round = Math.ceil(Math.log(1.0 / unit.rounding) / Math.log(10));
            }
            if(!qty_available_round) {
                var qty_available_round = 2;
            }
            $elem.html(product.qty_available.toFixed(qty_available_round));
            if (product.qty_available <= 0 && !$elem.hasClass('not-available')){
                $elem.addClass('not-available')
            }
        },
        push_order: function(order){
            var self = this;
            var pushed = PosModelSuper.prototype.push_order.call(this, order);
            if (order){
                order.orderlines.each(function(line){
                    var product = line.get_product();
                    product.qty_available -= line.get_quantity();
                    self.refresh_qty_available(product);
                })
            }
            return pushed;
        },
        push_and_invoice_order: function(order){
            var self = this;
            var invoiced = PosModelSuper.prototype.push_and_invoice_order.call(this, order);

            if (order && order.get_client()){
                if (order.orderlines){
                    order.orderlines.each(function(line){
                        var product = line.get_product();
                        product.qty_available -= line.get_quantity();
                        self.refresh_qty_available(product);
                    })
                } else if (order.orderlines){
                    order.orderlines.each(function(line){
                        var product = line.get_product();
                        product.qty_available -= line.get_quantity();
                        self.refresh_qty_available(product);
                    })
                }
            }

            return invoiced;
        },
    })

});
